Story Contract Pack
Session: session-2026-01-29T23-31-50-0f430f7b
Created: 2026-01-29T23:31:50.560Z

This is a "resume pack" for Stage 1 (Contract).
Upload this ZIP to continue to Stage 2 (Planning).

Files included:
- story_contract.json: The story's foundational constraints and rules
- state.json: Initial state (to be updated after each chunk)
- debug_log.json: Debug information for troubleshooting
