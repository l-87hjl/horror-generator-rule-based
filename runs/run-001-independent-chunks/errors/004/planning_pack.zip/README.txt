Story Planning Pack
Session: session-2026-01-29T18-37-14-e799c787
Created: 2026-01-29T19:27:05.669Z

This is a "resume pack" for Stage 2 (Planning).
Upload this ZIP to continue to Stage 3 (Generate Chunks).

Files included:
- story_contract.json: The story's foundational constraints
- state.json: Current state
- outline.json: Story structure and beats
- chunk_plan.json: What each chunk should accomplish

Next: POST to /api/staged/generate with this pack to generate chunks.
