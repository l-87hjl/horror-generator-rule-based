Story Resume Pack
Session: session-2026-01-29T18-37-14-e799c787
Created: 2026-01-29T19:52:11.823Z
Chunks completed: 1/9
Words generated: 1751/17000

Next action: continue
Download the resume pack and POST to /api/staged/generate with chunkNumber: 2

Files included:
- story_contract.json: The story's foundational constraints
- state.json: Current state (updated after chunk 1)
- audit_chunk_1.md: Gate audit report for this chunk
- chunks/: All generated chunks so far
