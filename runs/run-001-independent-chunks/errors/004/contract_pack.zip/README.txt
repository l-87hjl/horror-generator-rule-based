Story Contract Pack
Session: session-2026-01-29T18-37-14-e799c787
Created: 2026-01-29T18:37:14.803Z

This is a "resume pack" for Stage 1 (Contract).
Upload this ZIP to continue to Stage 2 (Planning).

Files included:
- story_contract.json: The story's foundational constraints and rules
- state.json: Initial state (to be updated after each chunk)
