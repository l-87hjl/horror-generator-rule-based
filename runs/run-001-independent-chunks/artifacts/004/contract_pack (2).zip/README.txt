Story Contract Pack
Session: session-2026-01-30T01-27-32-54a7f32b
Created: 2026-01-30T01:27:32.310Z

This is a "resume pack" for Stage 1 (Contract).
Upload this ZIP to continue to Stage 2 (Planning).

Files included:
- story_contract.json: The story's foundational constraints and rules
- state.json: Initial state (to be updated after each chunk)
- debug_log.json: Debug information for troubleshooting
