Story Planning Pack
Session: session-2026-01-30T01-27-32-54a7f32b
Created: 2026-01-30T01:28:56.323Z

This is a "resume pack" for Stage 2 (Planning).
Upload this ZIP to continue to Stage 3 (Generate Chunks).

Files included:
- story_contract.json: The story's foundational constraints
- state.json: Current state
- outline.json: Story structure and beats
- chunk_plan.json: What each chunk should accomplish
- debug_log.json: Debug information for troubleshooting

Next: POST to /api/staged/generate with this pack to generate chunks.
